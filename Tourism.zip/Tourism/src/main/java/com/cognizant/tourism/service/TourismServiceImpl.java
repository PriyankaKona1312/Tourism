package com.cognizant.tourism.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.tourism.Dao.TourismDAO;
import com.cognizant.tourism.entity.Tourism;
@Service
public class TourismServiceImpl implements TourismService {
	@Autowired
	private TourismDAO tourism;
	@Override
	@Transactional
	public List<Tourism> getAllTours() {
		// TODO Auto-generated method stub
		return tourism.getAllTours();
	}

	@Override
	@Transactional
	public void saveTour(Tourism tour) {
		// TODO Auto-generated method stub
		
		tourism.saveTour(tour);
	}

	@Override
	@Transactional
	public Tourism getTour(int theId) {
		// TODO Auto-generated method stub
		return tourism.getTour(theId);
	}
	@Override
	@Transactional
	public void deleteTour(int theId) {
		// TODO Auto-generated method stub
		tourism.deleteTour(theId);
	}

}
