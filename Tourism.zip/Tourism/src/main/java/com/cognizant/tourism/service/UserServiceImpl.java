package com.cognizant.tourism.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.tourism.Dao.UserDAO;
import com.cognizant.tourism.entity.Login;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDAO userDao;
	
	@Override
	@Transactional
	public boolean validateUser(String username, String password) {
		// TODO Auto-generated method stub
		return userDao.validateUser(username,password);
	}

	@Override
	@Transactional
	public void saveUser(Login login) {
		// TODO Auto-generated method stub
		userDao.saveUser(login);
	}

}
