package com.cognizant.tourism.Dao;

import com.cognizant.tourism.entity.Login;

public interface UserDAO {
	boolean validateUser(String username, String password);

	void saveUser(Login login);
}
